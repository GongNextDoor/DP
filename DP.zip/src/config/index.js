export default {
  baseApiPath: 'hygeia-bss/bss',
  dictApiPath: 'venus'
}
